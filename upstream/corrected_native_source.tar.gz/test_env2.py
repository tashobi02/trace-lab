import sys
import os

from affectively.environments import create_environment
from affectively.environments import GymToGymnasiumWrapper

class DummyArgs:
    def __init__(self):
        self.run = 0
        self.game = "solid"
        self.headless = 1
        self.weight = 0.5
        self.cluster = 0
        self.target_arousal = 1
        self.periodic_ra = 0
        self.cv = 0
        self.grayscale = 0
        self.discretize = 0
        self.classifier = 1
        self.preference = 1
        self.decision_period = 10
        self.imitate = 0

args = DummyArgs()
print("Creating environment...")
env = create_environment(args, args.run)
env = GymToGymnasiumWrapper(env)

print("Resetting environment...")
obs, info = env.reset()
print(f"Initial observation type: {type(obs)}, length: {len(obs)}")

print("Taking one step...")
# Sample action
action = env.action_space.sample()
obs, reward, terminated, truncated, info = env.step(action)
print(f"Step complete. Reward: {reward}, Terminated: {terminated}")

print("Closing environment...")
env.close()
print("Success!")
