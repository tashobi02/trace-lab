import sys
import os

from affectively.environments import create_environment
from affectively.environments import GymToGymnasiumWrapper

class DummyArgs:
    def __init__(self):
        self.run = 100
        self.game = "solid"
        self.headless = 1
        self.weight = 0.5
        self.cluster = 0
        self.target_arousal = 1
        self.periodic_ra = 0
        self.cv = 0
        self.grayscale = 0
        self.discretize = 0
        self.classifier = 1
        self.preference = 1
        self.decision_period = 10
        self.imitate = 0

args = DummyArgs()
env = create_environment(args, args.run)
env = GymToGymnasiumWrapper(env)

obs, info = env.reset()
done = False
truncated = False
steps = 0
while not (done or truncated) and steps < 1000:
    action = env.action_space.sample()
    obs, reward, done, truncated, info = env.step(action)
    steps += 1

print(f"Episode finished after {steps} steps. Done: {done}, Truncated: {truncated}, Final Reward: {reward}")
env.close()
